export { studentModel };

class studentModel {
  sender;
  letter;

  constructor(sender, letter) {
    this.sender = sender;
    this.letter = letter;
  }
}
